# Android-Based Smart Lock System

A basic Android app to simulate smart lock/unlock functionality using Bluetooth detection.

## Features
- Lock/unlock buttons
- Unlock only if Bluetooth is ON
- Simple UI

## Requirements
- Android Studio
- Android 5.0+

## License
MIT